

// document.addEventListener("DOMContentLoaded", function() {
//   const openBtn = document.querySelector(".open-btn");
//   const sidebar = document.querySelector(".sidebar");
//   const closeBtn = document.querySelector(".close-btn");

//   openBtn.addEventListener("click", function() {
//     sidebar.style.width = "250px";
//   });

//   closeBtn.addEventListener("click", function() {
//     sidebar.style.width = "0";
//   });


// });





function toggleSidebar() {
  var sidebar = document.getElementById("mySidebar");
  if (sidebar.style.width === "250px") {
    sidebar.style.width = "0";
  } else {
    sidebar.style.width = "250px";
  }
}

function closeSidebar() {
  document.getElementById("mySidebar").style.width = "0";
}
